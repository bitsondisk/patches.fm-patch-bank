All were duplicates of files that I already have.

Conclusion: All deleted.