Sysex for Yamaha DX5 which are the same as for Yamaha DX1:

DX5A1 = DX1A1
DX5A2 = DX1A2
DX5B1 = DX1B1
DX5B2 = DX1B2

There is a difference only in the header (on 1 only byte) so of course also in the checksum. There is absolutely no difference in their patches.